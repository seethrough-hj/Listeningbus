package org.techtown.myproject2;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

import static android.R.attr.x;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private BusStationXMLParser mXMLParser;
    private BusStationFirstXMLParser mXMLParser2;
    public double latitude;
    public double longitude;

    private TextView txtSpeechInput; // 음성 출력 대상
    private String busnum = "";   //음성입력 결과 저장
    private ImageButton btnSpeak;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private TextToSpeech tts;      //tts받으려고..

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        startLocationService();
        mXMLParser = new BusStationXMLParser("http://openapi.tago.go.kr/openapi/service/ArvlInfoInqireService/getSttnAcctoArvlPrearngeInfoList?ServiceKey=Utk4pE8vGB%2BaPGsKKwhKQreMwU2cR4K9Dxc7t%2BjJEdgetcgm3E1UGZhdeYDxTSzaydt5a8SvvDdEhNNDbDr7HA%3D%3D&cityCode=25&nodeId=DJB8001793ND", mHandler);
        Thread thread = new Thread(mXMLParser);
        thread.start();
        mXMLParser2 = new BusStationFirstXMLParser("http://openapi.tago.go.kr/openapi/service/BusSttnInfoInqireService/getCrdntPrxmtSttnList?ServiceKey=Utk4pE8vGB%2BaPGsKKwhKQreMwU2cR4K9Dxc7t%2BjJEdgetcgm3E1UGZhdeYDxTSzaydt5a8SvvDdEhNNDbDr7HA%3D%3D&gpsLati=36.039589&gpsLong=129.366269&numOfRows=999&pageSize=999&pageNo=1&startPage=1", mHandler2);
        Thread thread2 = new Thread(mXMLParser2);
        thread2.start();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtSpeechInput = (TextView) findViewById(R.id.txtSpeechInput);
        btnSpeak = (ImageButton) findViewById(R.id.btnSpeak);
        tts = new TextToSpeech(this, this);     //tts

        btnSpeak.setOnClickListener(new View.OnClickListener() {

                                        @Override
                                        public void onClick(View v) {
                                            promptSpeechInput();
                                        }


                                    }
        );
    }

    @Override
    public void onDestroy() {
        //tts 사용시 shut down 해야함
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override
    public void onInit(int status) {
        // TODO Auto-generated method stub
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(Locale.KOREA);

            // tts.setPitch(5); // 목소리 높낮이 조절
            // tts.setSpeechRate(2); // 말하는 빠르기 조절
            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "Language is not supported");
            } else {
                btnSpeak.setEnabled(true);
                speakOut();
            }
        } else {
            Log.e("TTS", "Initilization Failed");
        }

    }

    /**
     * Showing google speech input dialog
     */
    private void promptSpeechInput() {          //실제로 뜨는 구글마이크 그려진 창
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.speech_prompt));

        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void speakOut() {
        String text = txtSpeechInput.getText().toString();
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);  //null하나 더 추가
    }

    /**
     * Receiving speech input-> array 형태로 저장됨
     */

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && null != data) {
            while (!mXMLParser.isReady) ;
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            //txtSpeechInput.setText(result.get(0));
            busnum = result.get(0);
            speakOut();
        }
    }

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            ArrayList<BusArriveDatas> dataList1 = mXMLParser.getResult();
            int dataListSize = dataList1.size();

            for (int i = 0; x < dataListSize; i++) {
                double c = Double.parseDouble(dataList1.get(i).getBusNumber());
                double d = Double.parseDouble(dataList1.get(i).getBusTime());
            }
            Log.d("Data List Size1", Integer.toString(dataListSize));
            for (int i = 0; i < dataListSize; i++) {
                int time;
                time = Integer.parseInt(dataList1.get(i).getBusTime()) / 60;
                Log.d("Parsing Result", dataList1.get(i).getBusNumber() + "번 버스가 " + time + "분 후 도착합니다.");
            }

         /*   //음성녹음 된 버스번호와 일치하는 데이터를 buses에 넣기
            ArrayList<BusArriveDatas> buses = new ArrayList<>();
            for (BusArriveDatas bus : dataList1) {
                if (bus.getBusNumber().equals(busnum)) {
                    buses.add(bus);
                }
            }

            //같은 버스에 대한 여러 정보 중 거리가 더 가까운 정보 가져오기
            Collections.sort(buses);
            BusArriveDatas nearBus;
            nearBus = buses.get(0);
            nearBus.getBusNumber();
            nearBus.getBusTime();

            //출력code
            for (int i = 0; i < dataListSize; i++) {
                int time;
                time = Integer.parseInt(dataList1.get(i).getBusTime())/60;
                Log.d("Parsing Result", dataList1.get(i).getBusNumber() + "번 버스가 " + time + "분 후 도착합니다.");
            }

            int wantedTime = Integer.parseInt(nearBus.getBusTime())/60;
            int wantedNum= Integer.parseInt(nearBus.getBusNumber());


            if(String.valueOf(wantedNum) == null){
                txtSpeechInput.setText("잘못된 버스 번호이거나 버스 정보가 존재하지 않습니다");
            }
            else if (wantedTime<=2){
                txtSpeechInput.setText(wantedNum +  "번 버스가 잠시 후 도착합니다");
            }
            else txtSpeechInput.setText(wantedNum +  "번 버스가 " +  wantedTime + "분 후에 도착합니다");
        }*/
        }
    };


    Handler mHandler2 = new Handler() {

        @Override
        public void handleMessage(Message msg) {

            ArrayList<BusStationDatas> dataList2 = mXMLParser2.getResult();
            int dataListSize2 = dataList2.size();
            double[] store = new double[dataListSize2];


            for (int i = 0; i < dataListSize2; i++) {
                double a = Double.parseDouble(dataList2.get(i).getBusStationLati());
                double b = Double.parseDouble(dataList2.get(i).getBusStationLongi());
                double dist = distance(a, b, latitude, longitude);
                store[i] = dist;
            }

            double min = Double.MAX_VALUE;
            int minIndex = -1;

            for (int i = 0; i < store.length; i++) {
                if (store[i] < min) {
                    min = store[i];
                    minIndex = i;
                }
            }

            String perfect_busID = dataList2.get(minIndex).getBusID();

            Log.d("Data List Size2", Integer.toString(dataListSize2));
            for (int i = 0; i < dataListSize2; i++) {
                if (i == 0)
                    Log.d("현재 위치의 위도,경도", "위도(Lati) : " + dataList2.get(i).getBusStationLati() + " " + ">> 경도(Longi) : " + dataList2.get(i).getBusStationLongi());
                else
                    Log.d("버스 정류장의 위도,경도", i + "번 째의 버스정류장ID : " + dataList2.get(i).getBusID() + " >> 위도(Lati) : " + dataList2.get(i).getBusStationLati() + " " + ">> 경도(Longi) : " + dataList2.get(i).getBusStationLongi());
            }
            for (int i = 0; i < store.length; i++) {
                Log.d("거리계산 ", i + "번 째 정류장과 현재 위치와의 거리는 " + String.valueOf(store[i]));
            }
            Log.d("결과", "가장 가까운 정류장은 " + minIndex + "번 째 정류장입니다. 버스정류장의 ID는 \"" + perfect_busID + "\" 입니다.");
        }
    };

    public void startLocationService() {
        long minTime = 10000;
        float minDistance = 0;
        LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, 25);
        }

        manager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                minTime,
                minDistance,
                new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                    }

                    @Override
                    public void onStatusChanged(String s, int i, Bundle bundle) {
                    }

                    @Override
                    public void onProviderEnabled(String s) {
                    }

                    @Override
                    public void onProviderDisabled(String s) {
                    }
                });
    }

    public double distance(double lat1, double lon1, double lat2, double lon2) {

        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));

        dist = rad2deg(Math.acos(dist)) * 1609.344;
        return dist;
    }

    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double rad2deg(double rad) {
        return (rad * 180 / Math.PI);
    }
}

