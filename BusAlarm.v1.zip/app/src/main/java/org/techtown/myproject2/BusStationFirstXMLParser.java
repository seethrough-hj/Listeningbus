package org.techtown.myproject2;

import android.os.Handler;
import android.util.Log;

import org.xmlpull.v1.XmlPullParser;

import java.util.ArrayList;

public class BusStationFirstXMLParser extends FirstXMLParser implements Runnable {
    private ArrayList<BusStationDatas> mDataList2;
    private Handler mHandler2;

    public BusStationFirstXMLParser(String addr, Handler handler) {
        super(addr);
        // TODO Auto-generated constructor stub
        mHandler2 = handler;
    }

    public void startParsing() {
        // TODO Auto-generated method stub
        XmlPullParser parser = getXMLParser2("utf-8");

        if (parser == null) {
            mDataList2 = null;
            Log.d("B.S.FirstXMLParser", "Paser Object is null");
        } else {
            mDataList2 = new ArrayList<BusStationDatas>();
            String busStationID = null, busStationLati = null, busStationLongi = null;
            String tag;
            try {
                int parserEvent = parser.getEventType();
                int tagIdentifier = 0;

                while (parserEvent != XmlPullParser.END_DOCUMENT) {
                    switch (parserEvent) {
                        case XmlPullParser.START_DOCUMENT:
                            break;
                        case XmlPullParser.END_DOCUMENT:
                            break;
                        case XmlPullParser.START_TAG:
                            tag = parser.getName();
                            if (tag.equals("nodeid")) {
                                tagIdentifier = 1;
                            } else if (tag.equals("gpslati")) {
                                tagIdentifier = 2;
                            } else if (tag.equals("gpslong")) {
                                tagIdentifier = 3;
                            }
                            break;
                        case XmlPullParser.END_TAG:
                            break;
                        case XmlPullParser.TEXT:
                            if (tagIdentifier == 1) {
                                busStationID = parser.getText().trim();
                            } else if (tagIdentifier == 2) {
                                busStationLati = parser.getText().trim();
                            } else if (tagIdentifier == 3) {
                                busStationLongi = parser.getText().trim();
                                BusStationDatas data = new BusStationDatas(busStationID, busStationLati, busStationLongi);
                                mDataList2.add(data);
                            }
                            tagIdentifier = 0;
                            break;
                    }
                    parserEvent = parser.next();
                }
            } catch (Exception e) {
                Log.d("B.S.XMLParser", e.getMessage());
            }
        }

        Log.d("BusStationXMLResult", Integer.toString(mDataList2.size()));
    }

    public ArrayList<BusStationDatas> getResult() {
        return mDataList2;
    }

    public void run() {
        // TODO Auto-generated method stub
        startParsing();
        mHandler2.sendEmptyMessage(0);
    }

}
