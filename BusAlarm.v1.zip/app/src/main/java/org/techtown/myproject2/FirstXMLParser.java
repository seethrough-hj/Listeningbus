package org.techtown.myproject2;

import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.net.URL;

public abstract class FirstXMLParser {
      private String mAddr2;

      public FirstXMLParser(String addr2){
          mAddr2 = addr2;
      }

      public XmlPullParser getXMLParser2(String type){
          try{
              URL targetURL = new URL(mAddr2);
              InputStream is = targetURL.openStream();

              XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
              XmlPullParser parser = factory.newPullParser();

              parser.setInput(is, type);

              return parser;
           }catch(Exception e){
               Log.d("FirstXMLParser", e.getMessage());
               return null;
           }
       }

      public abstract void startParsing();
  }