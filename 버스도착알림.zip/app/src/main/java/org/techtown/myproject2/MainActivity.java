package org.techtown.myproject2;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {

    private long mStartTime, mEndTime;
    private BusStationXMLParser mXMLParser;

    private TextView txtSpeechInput; // 음성 출력 대상
    private String busnum = "";   //음성입력 결과 저장
    private ImageButton btnSpeak;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private TextToSpeech tts;      //tts받으려고..

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtSpeechInput = (TextView) findViewById(R.id.txtSpeechInput);
        btnSpeak = (ImageButton) findViewById(R.id.btnSpeak);
        tts = new TextToSpeech(this, this);     //tts

        btnSpeak.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                promptSpeechInput();
            }
        });
    }

    @Override
    public void onDestroy() {
        //tts 사용시 shut down 해야함
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @Override
    public void onInit(int status) {
        // TODO Auto-generated method stub
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(Locale.KOREA);

            // tts.setPitch(5); // 목소리 높낮이 조절
            // tts.setSpeechRate(2); // 말하는 빠르기 조절
            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "Language is not supported");
            } else {
                btnSpeak.setEnabled(true);
                speakOut();
            }
        } else {Log.e("TTS", "Initilization Failed");}

    }

    /**
     * Showing google speech input dialog
     */
    private void promptSpeechInput() {          //실제로 뜨는 구글마이크 그려진 창
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.speech_prompt));

        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void speakOut() {
        String text = txtSpeechInput.getText().toString();
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);  //null하나 더 추가
    }

    /**
     * Receiving speech input-> array 형태로 저장됨
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && null != data) {
            mXMLParser = new BusStationXMLParser("http://openapi.tago.go.kr/openapi/service/ArvlInfoInqireService/getSttnAcctoArvlPrearngeInfoList?ServiceKey=Utk4pE8vGB%2BaPGsKKwhKQreMwU2cR4K9Dxc7t%2BjJEdgetcgm3E1UGZhdeYDxTSzaydt5a8SvvDdEhNNDbDr7HA%3D%3D&cityCode=37010&nodeId=PHB351008001", mHandler);

            Thread thread = new Thread(mXMLParser);
            thread.start();

            while(!mXMLParser.isReady) ;

            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            //txtSpeechInput.setText(result.get(0));
            busnum = result.get(0);
            speakOut();
        }
    }

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            ArrayList<BusArriveDatas> dataList = mXMLParser.getResult();
            int dataListSize = dataList.size();
            Log.d("Data List Size", Integer.toString(dataListSize));

            //음성녹음 된 버스번호와 일치하는 데이터를 buses에 넣기
            ArrayList<BusArriveDatas> buses = new ArrayList<>();
            for (BusArriveDatas bus : dataList) {
                if (bus.getBusNumber().equals(busnum)) {
                    buses.add(bus);
                }
            }

            //같은 버스에 대한 여러 정보 중 거리가 더 가까운 정보 가져오기
            Collections.sort(buses);
            BusArriveDatas nearBus;
            nearBus = buses.get(0);
            nearBus.getBusNumber();
            nearBus.getBusTime();

            //출력code
            for (int i = 0; i < dataListSize; i++) {
                int time;
                time = Integer.parseInt(dataList.get(i).getBusTime())/60;
                Log.d("Parsing Result", dataList.get(i).getBusNumber() + "번 버스가 " + time + "분 후 도착합니다.");
            }

            int wantedTime = Integer.parseInt(nearBus.getBusTime())/60;
            int wantedNum= Integer.parseInt(nearBus.getBusNumber());


            if(String.valueOf(wantedNum) == null){
                txtSpeechInput.setText("잘못된 버스 번호이거나 버스 정보가 존재하지 않습니다");
            }
             else if (wantedTime<=2){
                txtSpeechInput.setText(wantedNum +  "번 버스가 잠시 후 도착합니다");
            }
            else txtSpeechInput.setText(wantedNum +  "번 버스가 " +  wantedTime + "분 후에 도착합니다");
        }
    };
}