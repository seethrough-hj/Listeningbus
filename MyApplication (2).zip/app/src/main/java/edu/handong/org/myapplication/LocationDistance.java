package edu.handong.org.myapplication;

import android.util.Log;

/**
 * Created by user on 2017-08-08.
 */

public class LocationDistance extends BusStationDatas{

      static String busStationLati;
      static String busStationLongi;
      static String MyLocationLati;
      static String MyLocationLogi;

    public LocationDistance(String busStationLati, String busStationLongi, String MyLocationLati, String MyLocationLongi) {
        double lat1 = Double.parseDouble(busStationLati);
        double lon1 = Double.parseDouble(busStationLongi);
        double lat2 = Double.parseDouble(MyLocationLati);
        double lon2 = Double.parseDouble(MyLocationLongi);

        this.busStationLati = busStationLati;
        this.busStationLongi = busStationLongi;
        this.MyLocationLati = MyLocationLati;
        this.MyLocationLogi = MyLocationLogi;

        double distanceMeter =
                distance(lat1, lon1, lat2,lon2);
                Log.d("Distance", distance);
    }



    private static double distance(double lat1, double lon1, double lat2, double lon2) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1))*Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1))*Math.cos(deg2rad(lat2))*Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist*1609.344;

        return (dist);
    }


    private static double deg2rad(double deg) {
        return (deg*Math.PI/180.0);
    }

    private static double rad2deg(double rad) {
        return (rad*180/Math.PI);
    }
}
