package edu.handong.org.myapplication;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private long mStartTime, mEndTime;
    private BusStationXMLParser mXMLParser;
    private LocationDistance mDistance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                startLocationService();

                // TODO Auto-generated method stub
                mStartTime = System.currentTimeMillis();
                mXMLParser = new BusStationXMLParser("http://openapi.tago.go.kr/openapi/service/BusSttnInfoInqireService/getCrdntPrxmtSttnList?ServiceKey=Utk4pE8vGB%2BaPGsKKwhKQreMwU2cR4K9Dxc7t%2BjJEdgetcgm3E1UGZhdeYDxTSzaydt5a8SvvDdEhNNDbDr7HA%3D%3D&gpsLati=36.039589&gpsLong=129.366269&numOfRows=999&pageSize=999&pageNo=1&startPage=1", mHandler);
                Thread thread = new Thread(mXMLParser);
                thread.start();
                //mDistance = new LocationDistance(LocationDistance.busStationLati, LocationDistance.busStationLongi);
            }
        });
    }

    public void startLocationService() {
        long minTime = 10000;
        float minDistance = 0;
        LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if ( ContextCompat.checkSelfPermission( this, android.Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED ) {

            ActivityCompat.requestPermissions( this, new String[] {  android.Manifest.permission.ACCESS_COARSE_LOCATION  }, 26);
        }

        manager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                minTime,
                minDistance,
                new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {
                        Double latitude = location.getLatitude();
                        Double longitude = location.getLongitude();
                        Log.d("Latitude, Longitude", String.valueOf(latitude) +">>>"+ String.valueOf(longitude));
                    }

                    @Override
                    public void onStatusChanged(String s, int i, Bundle bundle) {

                    }

                    @Override
                    public void onProviderEnabled(String s) {

                    }

                    @Override
                    public void onProviderDisabled(String s) {

                    }
                }
        );

    }

    Handler mHandler = new Handler(){

        @Override
        public void handleMessage(Message msg) {
            // TODO Auto-generated method stub
            mEndTime = System.currentTimeMillis();
            Log.d("Taken Time", Long.toString((mEndTime - mStartTime) / 1000L));
            ArrayList<BusStationDatas> dataList = mXMLParser.getResult();
            int dataListSize = dataList.size();
            Log.d("Data List Size", Integer.toString(dataListSize));
            for(int i = 0; i < dataListSize; i++){
                Log.d("XML Parsing Result", dataList.get(i).getBusID()+ " >>> " + "Station Lati : " + dataList.get(i).getBusStationLati() + " >>> " + "Station Longi : " + dataList.get(i).getBusStationLongi());
            }
        }




    };



 }